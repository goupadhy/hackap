
/*
 * GET home page.
 */

 

exports.index = function(req, res){
	//response.render('login.html', { message: request.flash('error') });
  res.render('index.html', { title: 'Cloudant Boiler Plate' });
};

